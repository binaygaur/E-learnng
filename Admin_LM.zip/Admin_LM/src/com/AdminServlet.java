/**
 * Author Name					Date							Discription
 * ---------------------------------------------------------------------------------------------------------------
 * Pankaj Sewalia				23-May-2014						Controller Servlet for admin module of LMS
 * ---------------------------------------------------------------------------------------------------------------
 */
package com;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
// Extend HttpServlet class
public class AdminServlet extends HttpServlet { 
  @Override
  public void init() throws ServletException{ /* Do required initialization*/ } 
  ArrayList<String> list =null;
  @Override
  public void doGet(HttpServletRequest request,HttpServletResponse response)
            throws ServletException, IOException {
	  doPost(request,response);
  }
  @Override
  public void doPost(HttpServletRequest request,HttpServletResponse response)
            throws ServletException, IOException {
      String jMessage = null; 
      response.setContentType("text/html"); 
      //PrintWriter out = response.getWriter();
      String jEventName = request.getParameter("jEventName");
	  System.out.println("jEventName: " + jEventName);
      if(jEventName != null && jEventName.equalsIgnoreCase("AdminLogin")){//add code for AdminLogin
          String username = request.getParameter("user_id");
          String password = request.getParameter("pass");
          list = new ArrayList<String>();
          list.add(0,username);
          list.add(1,password);
          if(isAllowed()){jMessage = "";request.setAttribute("jMessage", jMessage);request.setAttribute("jEventName", jEventName);request.getRequestDispatcher("AdminMain.jsp").forward(request, response);
          }else{
        	  jMessage = "Enter User Name and Password is not correct";request.setAttribute("jMessage", jMessage);request.setAttribute("jEventName", jEventName);request.getRequestDispatcher("AdminLogin.jsp").forward(request, response);}
      }else if(jEventName != null && jEventName.equalsIgnoreCase("T_Create")){//add code for T_Create
    	  String teacherId = request.getParameter("t_id"); 
    	  String teacherName = request.getParameter("t_name");
    	  String user = request.getParameter("user");
          String password = request.getParameter("pwd");
          String fatherName = request.getParameter("f_name");
          String dob= request.getParameter("dob");
          String sex = request.getParameter("sex");
          String address = request.getParameter("address");
          String email = request.getParameter("email");
          String mobile= request.getParameter("mobile");
          
          list = new ArrayList<String>();
          list.add(0, teacherId);
          list.add(1, teacherName);
          list.add(2, user);
          list.add(3, password);
          list.add(4, fatherName);
          list.add(5, dob);
          list.add(6, sex);
          list.add(7, address);
          list.add(8, email);
          list.add(9, mobile);
          if(checkTeacherId(teacherId)){
        	  jMessage = "provided Teacher Id is already exist...please choose another teacher Id";  request.setAttribute("jEventName", jEventName); request.setAttribute("jMessage", jMessage)
        	  ;request.getRequestDispatcher("T_Create.jsp").forward(request, response); }else{ if(sendTeacher()){ jMessage = "New Teacher Successfully created"; request.setAttribute("jEventName", jEventName);
        	  request.setAttribute("jMessage", jMessage); request.getRequestDispatcher("Success.jsp").forward(request, response);}
          }
      }else if(jEventName != null && jEventName.equalsIgnoreCase("S_Create")){//add code for S_Create
    	  String studentId = request.getParameter("s_id"); 
    	  String studentName = request.getParameter("s_name");
    	  String user = request.getParameter("user");
          String password = request.getParameter("pwd");
          String fatherName = request.getParameter("f_name");
          String dob= request.getParameter("dob");
          String sex = request.getParameter("sex");
          String address = request.getParameter("address");
          String email = request.getParameter("email");
          String mobile= request.getParameter("mobile");
          
          list = new ArrayList<String>();
          list.add(0, studentId);
          list.add(1, studentName);
          list.add(2, user);
          list.add(3, password);
          list.add(4, fatherName);
          list.add(5, dob);
          list.add(6, sex);
          list.add(7, address);
          list.add(8, email);
          list.add(9, mobile);
          if(checkStudentId(studentId)){
        	  jMessage = "provided Student Id is already exist...please choose another student Id";  request.setAttribute("jEventName", jEventName); request.setAttribute("jMessage", jMessage)
        	  ;request.getRequestDispatcher("S_Create.jsp").forward(request, response); }else{ if(sendStudent()){ jMessage = "New student Successfully created"; request.setAttribute("jEventName", jEventName);
        	  request.setAttribute("jMessage", jMessage); request.getRequestDispatcher("Success.jsp").forward(request, response);}
          }
      }else if(jEventName != null && jEventName.equalsIgnoreCase("T_Query")){//add code for T_Query
          String teacherId = request.getParameter("teacher_id");
          String teacherQuery = request.getParameter("teacher_query"); 
          //get earlier queries from the same teacher id starts
          ArrayList<String> queryArrList = new ArrayList<String>();
    	  ArrayList<String> jTeacherInfo = new ArrayList<String>();
          queryArrList = getQueries(teacherId);
          jTeacherInfo = getTeacherById(teacherId);
          //get earlier queries from the same teacher id starts
          jMessage = "Teacher Id you provided is not available"; 
          //System.out.println("teacherId:  "+teacherId); 
          if(checkTeacherId(teacherId)){
              list =  new ArrayList<String>();
              list.add(0, teacherId);
              list.add(1, teacherQuery);   
              //System.out.println("list:  "+list); 
              if(sendQuery()){
            	  request.setAttribute("jTeacherInfo", jTeacherInfo);request.setAttribute("jQueryArrList", queryArrList);request.setAttribute("jEventName", jEventName);request.setAttribute(
            			  "jTeacherId", teacherId); request.getRequestDispatcher("Acknowledge.jsp").forward(request, response) ;}
          }else{request.setAttribute("jEventName", jEventName);request.setAttribute("jMessage", jMessage);request.getRequestDispatcher("T_Query.jsp").forward(request, response);}
      }
      else if(jEventName != null && jEventName.equalsIgnoreCase("V_T_Logs")){//add code for T_Logs
          String teacherId = request.getParameter("t_id");
       
          //get earlier queries from the same teacher id starts
         
          //get earlier queries from the same teacher id starts
          jMessage = "Teacher Id you provided is not available"; 
          //System.out.println("teacherId:  "+teacherId); 
              list =  new ArrayList<String>();
              list.add(0, teacherId);
              //System.out.println("list:  "+list); 
              ArrayList<String> chapterAL = new ArrayList<String>();
              ArrayList<String> testAL = new ArrayList<String>();
        	  ArrayList<String> assignmentAL = new ArrayList<String>();
        	  ArrayList<String> videoAL = new ArrayList<String>();
        	  ArrayList<String> bookAL = new ArrayList<String>();
        	  chapterAL=getLogChapters();
        	  testAL=getLogTests();
        	  assignmentAL=getLogAssignments();
        	  videoAL=getLogVideos();
        	  bookAL=getLogBooks();
             
            	  request.setAttribute("chapterAL", chapterAL); request.setAttribute("testAL", testAL); request.setAttribute("assignmentAL", assignmentAL); request.setAttribute("videoAL", videoAL); request.setAttribute("bookAL", bookAL);request.setAttribute("jEventName", jEventName);request.setAttribute(
            			  "jTeacherId", teacherId); request.getRequestDispatcher("V_T_log.jsp").forward(request, response) ;
          
      }else if(jEventName != null && jEventName.equalsIgnoreCase("T_Audit")){//add code for T_Audit
      }else if(jEventName != null && jEventName.equalsIgnoreCase("S_profile")){//add code for S_profile
      }
   } 
  @Override
  public void destroy(){ /* do nothing.*/ }  
  private Connection getConnection(){
	  Connection con= null;
	  try{
		  Class.forName("com.mysql.jdbc.Driver");
		  con= DriverManager.getConnection("jdbc:mysql://localhost/Final_Teacher","root","");
	  	} catch(Exception e){
		  System.out.println(e);
		  e.printStackTrace();
	  	}
	  return con;
  }
  private void closeConnection(Connection con){
	  try{
		  if(con != null){
			con.close();
		  }
	  }catch(SQLException sqe){
		  System.out.println(sqe);
		  sqe.printStackTrace();
	  }
  }
  private boolean isAllowed(){
	  //System.out.println("username :  "+username +"  password :  "+password);	 
	  Connection con = null;
	  int count= 0;
	  try
	  {
		  con = getConnection(); 
		  String sql = "SELECT COUNT(1) FROM lms_main_admin WHERE USER_NAME= ? and PASSWORD=?";
			PreparedStatement ps = con.prepareStatement(sql);
			if(!list.isEmpty()){
				ps.setString(1, list.get(0));
				ps.setString(2, list.get(1));
				ResultSet rs=ps.executeQuery();
				while(rs.next()){
					count= rs.getInt(1);
				}
			}
	  }
	  catch(SQLException sqe){
		System.out.println(sqe);sqe.printStackTrace();
	}finally{closeConnection(con);}
	  if(count != 0)
		  return true;
	  else 
		  return false;
  }
  private boolean sendTeacher(){	
	  //System.out.println("list :  "+list);
	Connection con = null;
	int value = -1;
	//int n=-1;
	try{
		con = getConnection(); 
		String sql = "INSERT INTO lms_main_teacher VALUES(?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		if(!list.isEmpty()){
			 DateFormat formatter ; 
		     formatter = new SimpleDateFormat("dd-MMM-yyyy");
		     Date date=formatter.parse(list.get(5));
		     java.sql.Date d=new java.sql.Date(date.getTime());
		     
			ps.setString(1, list.get(0));
			ps.setString(2, list.get(1));
			ps.setString(3, list.get(2));
			ps.setString(4, list.get(3));
			ps.setString(5, list.get(4));
			ps.setDate(6, d);
			ps.setString(7, list.get(6));
			ps.setString(8, list.get(7));
			ps.setString(9, list.get(8));
			ps.setString(10, list.get(9));
			
			value = ps.executeUpdate();	
			/*
			if(n != -1)
			{
				String sql2 = "INSERT INTO teacher_login VALUES(?,?,?,?)";
				PreparedStatement ps2 = con.prepareStatement(sql2);
				ps2.setString(1, list.get(0));
				ps2.setString(2, list.get(1));
				ps2.setString(3, list.get(3));
				ps2.setString(4, list.get(8));
				value = ps.executeUpdate();	
			}*/
		}
	}catch(SQLException sqe){
		System.out.println(sqe);sqe.printStackTrace();
	}
	catch(Exception e){
		System.out.println(e);e.printStackTrace();
	}
	finally{closeConnection(con);}
	if(value != -1){return true;}else return false;
  }
  private boolean sendStudent(){	
	  //System.out.println("list :  "+list);
	Connection con = null;
	int value = -1;
	//int n=-1;
	try{
		con = getConnection(); 
		String sql = "INSERT INTO lms_main_student VALUES(?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		if(!list.isEmpty()){
			 DateFormat formatter ; 
		     formatter = new SimpleDateFormat("dd-MMM-yyyy");
		     Date date=formatter.parse(list.get(5));
		     java.sql.Date d=new java.sql.Date(date.getTime());
		     
			ps.setString(1, list.get(0));
			ps.setString(2, list.get(1));
			ps.setString(3, list.get(2));
			ps.setString(4, list.get(3));
			ps.setString(5, list.get(4));
			ps.setDate(6, d);
			ps.setString(7, list.get(6));
			ps.setString(8, list.get(7));
			ps.setString(9, list.get(8));
			ps.setString(10, list.get(9));
			
			value = ps.executeUpdate();	
			/*
			if(n != -1)
			{
				String sql2 = "INSERT INTO student_login VALUES(?,?,?,?)";
				PreparedStatement ps2 = con.prepareStatement(sql2);
				ps2.setString(1, list.get(0));
				ps2.setString(2, list.get(1));
				ps2.setString(3, list.get(3));
				ps2.setString(4, list.get(8));
				value = ps.executeUpdate();	
			}*/
		}
	}catch(SQLException sqe){
		System.out.println(sqe);sqe.printStackTrace();
	}
	catch(Exception e){
		System.out.println(e);e.printStackTrace();
	}
	finally{closeConnection(con);}
	if(value != -1){return true;}else return false;
  }
  private boolean sendQuery(){	
    //System.out.println("list :  "+list);
	Connection con = null;
	int value = -1;
	try{
        //changing timestamp zone starts 
			//java.util.Date date = new java.util.Date();				    
		    Time time = new Time(19800000);
		    Calendar c = Calendar.getInstance();		     
		    Timestamp timestamp = new Timestamp( c.getTimeInMillis() + time.getTime() );		        
		 	//java.util.Date newDate = new java.util.Date(timestamp.getTime() );
		 //changing timestamp zone ends 
		con = getConnection(); 
		String sql = "INSERT INTO lms_teacher_query(TEACHER_ID, QUERY_STRING, QUERY_TIMESTAMP) VALUES(?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		if(!list.isEmpty()){
			ps.setString(1, list.get(0));
			ps.setString(2, list.get(1));
			ps.setString(3, timestamp.toString());	
			value = ps.executeUpdate();				
		}
	}catch(SQLException sqe){
		System.out.println(sqe);
		sqe.printStackTrace();
	}finally{closeConnection(con);}
	if(value != -1)return true;else return false;
  }
  private boolean checkTeacherId(String teacherId){
	Connection con = null;
	ResultSet rs = null;
	int countTID = 0;
	try{
		con = getConnection(); 
		String sql = "SELECT COUNT(1) FROM lms_main_teacher WHERE TEACHER_ID = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, teacherId);
		rs = ps.executeQuery();
		while(rs.next()){
			//System.out.println("countTID:  "+countTID);
			countTID = rs.getInt(1);
		}
	}catch(SQLException sqe){
		System.out.println(sqe);
		sqe.printStackTrace();
	}finally{closeConnection(con);}
	if(countTID != 0)return true;else return false;
  }
  private boolean checkStudentId(String teacherId){
		Connection con = null;
		ResultSet rs = null;
		int countTID = 0;
		try{
			con = getConnection(); 
			String sql = "SELECT COUNT(1) FROM lms_main_student WHERE STUDENT_ID = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, teacherId);
			rs = ps.executeQuery();
			while(rs.next()){
				//System.out.println("countTID:  "+countTID);
				countTID = rs.getInt(1);
			}
		}catch(SQLException sqe){
			System.out.println(sqe);
			sqe.printStackTrace();
		}finally{closeConnection(con);}
	
		if(countTID != 0)return true;else return false;
	  }
  private ArrayList<String> getQueries(String teacherId){
	ArrayList<String> aList = new ArrayList<String>();	
	Connection con = null;
	ResultSet rs = null;
	try{
		con = getConnection(); 
		String sql = "SELECT QUERY_STRING, ACK_QUERY,QUERY_TIMESTAMP FROM lms_teacher_query WHERE TEACHER_ID = ? ORDER BY QUERY_TIMESTAMP DESC";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, teacherId);
		rs = ps.executeQuery();
		int i=0;
		while(rs.next()){
			aList.add(i,rs.getInt(2)+"/"+rs.getString(1)+"/"+rs.getString(3));
			i++;
		}		
	}catch(SQLException sqe){
		System.out.println(sqe);
		sqe.printStackTrace();
	}finally{closeConnection(con);}	
	return aList;
  }
  private ArrayList<String> getTeacherById(String teacherId){
	  ArrayList<String> aList = new ArrayList<String>();
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection(); 
			String sql = "SELECT NAME, USERNAME, SUBJECT FROM lms_main_teacher WHERE TEACHER_ID = ? ";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, teacherId);
			rs = ps.executeQuery();
			while(rs.next()){
				aList.add(0,rs.getString(1));
				aList.add(1,rs.getString(2));
				aList.add(2,rs.getString(3));
			}		
		}catch(SQLException sqe){
			System.out.println(sqe);
			sqe.printStackTrace();
		}finally{closeConnection(con);}	
		return aList;
	  
  }
  private ArrayList<String> getLogChapters()
  {
	  ArrayList<String> aList = new ArrayList<String>();	
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection(); 
			String sql="SELECT N.CHAPTER_ID,N.CHAPTER_NAME,N.DESCRIPTIONS, CL.CLASS_NAME, S.SUBJECT_NAME FROM (((CHAPTER_ADDED AS CA JOIN NEW_CHAPTER AS N ON N.CHAPTER_ID = CA.CHAPTER_ID)	JOIN SUBJECTS AS S ON CA.SUBJECT_ID = S.SUBJECT_ID) JOIN CLASS AS CL ON  CL.CLASS_ID = CA.CLASS_ID) WHERE CA.Teacher_Id =?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,list.get(0));
			rs = ps.executeQuery();
			int i=0;
			while(rs.next()){
				aList.add(i,rs.getString("CL.CLASS_NAME")+"/"+rs.getString("S.SUBJECT_NAME")+"/"+rs.getString("N.CHAPTER_ID")+"/"+rs.getString("N.CHAPTER_NAME")+"/"+rs.getString("N.DESCRIPTIONS"));
				i++;
			}		
		}catch(SQLException sqe){
			System.out.println(sqe);
			sqe.printStackTrace();
		}finally{closeConnection(con);}	
		return aList; 
  }
  private ArrayList<String> getLogTests()
  {
	  ArrayList<String> aList = new ArrayList<String>();	
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection(); 
			String sql="SELECT DISTINCT T.TEST_ID, T.CHAPTER_ID, C.TEST_NAME,C.No_of_section, N.CHAPTER_ID,N.CHAPTER_NAME, CL.CLASS_NAME, S.SUBJECT_NAME, C.TEST_TIME, C.CREATED_DATE FROM (((((	CHAPTER_TEST AS T JOIN CREATE_TEST AS C ON T.TEST_ID = C.TEST_ID ) JOIN CHAPTER_ADDED AS CA ON CA.CHAPTER_ID = T.CHAPTER_ID) JOIN NEW_CHAPTER AS N ON N.CHAPTER_ID = CA.CHAPTER_ID)	JOIN SUBJECTS AS S ON CA.SUBJECT_ID = S.SUBJECT_ID) JOIN CLASS AS CL ON  CL.CLASS_ID = CA.CLASS_ID) WHERE CA.Teacher_Id =? ORDER BY CREATED_DATE DESC";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,list.get(0));
			rs = ps.executeQuery();
			int i=0;
			while(rs.next()){
				aList.add(i,rs.getString("CL.CLASS_NAME")+"/"+rs.getString("S.SUBJECT_NAME")+"/"+rs.getString("N.CHAPTER_ID")+"/"+rs.getString("N.CHAPTER_NAME")+"/"+rs.getString("T.TEST_ID")+"/"+rs.getString("C.TEST_NAME")+"/"+rs.getString("C.CREATED_DATE")+"/"+rs.getString("C.TEST_TIME"));
				i++;
			}		
		}catch(SQLException sqe){
			System.out.println(sqe);
			sqe.printStackTrace();
		}finally{closeConnection(con);}	
		return aList; 
  }
  private ArrayList<String> getLogAssignments()
  {
	  ArrayList<String> aList = new ArrayList<String>();	
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection(); 
			String sql = "SELECT DISTINCT T.ASSIGNMENT_ID, T.CHAPTER_ID,N.Chapter_Id, N.CHAPTER_NAME, CL.CLASS_NAME, S.SUBJECT_NAME,S.SUBJECT_ID,C.ASSIGNMENT_TYPE,C.FILE_NAME,C.UPLOAD_DATE FROM (((((CHAPTER_Assignment AS T JOIN CREATE_ASSIGNMENT AS C ON T.ASSIGNMENT_ID = C.ASSIGNMENT_ID ) JOIN CHAPTER_ADDED AS CA ON CA.CHAPTER_ID = T.CHAPTER_ID) JOIN NEW_CHAPTER AS N ON N.CHAPTER_ID = CA.CHAPTER_ID)	JOIN SUBJECTS AS S ON CA.SUBJECT_ID = S.SUBJECT_ID)  JOIN CLASS AS CL ON CL.CLASS_ID = CA.CLASS_ID) WHERE CA.Teacher_Id =? ORDER BY UPLOAD_DATE DESC";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,list.get(0));
			rs = ps.executeQuery();
			int i=0;
			while(rs.next()){
				aList.add(i,rs.getString("CL.CLASS_NAME")+"/"+rs.getString("S.SUBJECT_NAME")+"/"+rs.getString("N.CHAPTER_ID")+"/"+rs.getString("N.CHAPTER_NAME")+"/"+rs.getString("T.ASSIGNMENT_ID")+"/"+rs.getString("C.FILE_NAME")+"/"+rs.getString("C.UPLOAD_DATE"));
				i++;
			}		
		}catch(SQLException sqe){
			System.out.println(sqe);
			sqe.printStackTrace();
		}finally{closeConnection(con);}	
		return aList; 
  }
  private ArrayList<String> getLogVideos()
  {
	  ArrayList<String> aList = new ArrayList<String>();	
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection(); 
			String sql="SELECT Video_Id,Video_Name,Video_Description,File_Name,NC.Chapter_Name,CA.CHAPTER_ID,C.CLASS_NAME,S.SUBJECT_NAME from ((((CHAPTER_ADDED AS CA JOIN VIDEOS AS B ON B.Chapter_Id=CA.Chapter_Id)JOIN CLASS AS C ON C.CLASS_ID=CA.CLASS_ID)JOIN SUBJECTS AS S ON S.SUBJECT_ID=CA.SUBJECT_ID)JOIN NEW_CHAPTER AS NC ON CA.CHAPTER_ID=NC.CHAPTER_ID) WHERE B.TEACHER_ID=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,list.get(0));
			rs = ps.executeQuery();
			int i=0;
			while(rs.next()){
				aList.add(i,rs.getString("C.CLASS_NAME")+"/"+rs.getString("S.SUBJECT_NAME")+"/"+rs.getString("CA.CHAPTER_ID")+"/"+rs.getString("NC.CHAPTER_NAME")+"/"+rs.getString("Video_Id")+"/"+rs.getString("Video_Name")+"/"+rs.getString("Video_Description")+"/"+rs.getString("File_Name"));
				i++;
			}		
		}catch(SQLException sqe){
			System.out.println(sqe);
			sqe.printStackTrace();
		}finally{closeConnection(con);}	
		return aList; 
  }
  private ArrayList<String> getLogBooks()
  {
	  ArrayList<String> aList = new ArrayList<String>();	
		Connection con = null;
		ResultSet rs = null;
		try{
			con = getConnection(); 
			String sql="SELECT BOOK_ID,BOOK_NAME,DESCRIPTION,BOOK_TYPE,NAME_URL,NC.CHAPTER_NAME,C.CHAPTER_ID,CL.CLASS_NAME,S.SUBJECT_NAME FROM ((((CHAPTER_ADDED AS C JOIN BOOKS AS B ON B.Chapter_Id=C.Chapter_Id)JOIN NEW_CHAPTER AS NC ON NC.CHAPTER_ID=C.CHAPTER_ID)JOIN SUBJECTS AS S ON C.SUBJECT_ID=S.SUBJECT_ID)JOIN CLASS AS CL ON CL.CLASS_ID=C.CLASS_ID)  WHERE B.TEACHER_ID=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,list.get(0));
			rs = ps.executeQuery();
			int i=0;
			while(rs.next()){
				aList.add(i,rs.getString("CL.CLASS_NAME")+"%"+rs.getString("S.SUBJECT_NAME")+"%"+rs.getString("C.CHAPTER_ID")+"%"+rs.getString("NC.CHAPTER_NAME")+"%"+rs.getString("BOOK_ID")+"%"+rs.getString("BOOK_NAME")+"%"+rs.getString("DESCRIPTION")+"%"+rs.getString("NAME_URL")+"%"+rs.getString("BOOK_TYPE"));
				i++;
			}		
		}catch(SQLException sqe){
			System.out.println(sqe);
			sqe.printStackTrace();
		}finally{closeConnection(con);}	
		return aList; 
  }
//end of the controller
}