package com;
import java.sql.*;
public class MyConnection {
Connection c;
 public Connection getConnection()
 {
	 try
	 {
	 	Class.forName("com.mysql.jdbc.Driver");
		c= DriverManager.getConnection("jdbc:mysql://localhost/Final_Teacher","root","");
		
	 }
	 catch(Exception e)
	 {
		e.printStackTrace(); 
	 }
		return c;
 }
	
}

